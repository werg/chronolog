// server/test/public-fixture.ts
import { env as env2 } from "cloudflare:workers";
import { applyD1Migrations } from "cloudflare:test";

// server/test/helpers.ts
import { env, exports } from "cloudflare:workers";
import { runDurableObjectAlarm, runInDurableObject } from "cloudflare:test";

// server/src/ids.ts
async function sha256Hex(data) {
  const bytes2 = typeof data === "string" ? new TextEncoder().encode(data) : data;
  const digest = await crypto.subtle.digest("SHA-256", bytes2);
  return hex(new Uint8Array(digest));
}
function hex(bytes2) {
  let s = "";
  for (const b of bytes2) s += b.toString(16).padStart(2, "0");
  return s;
}

// server/test/helpers.ts
var BASE = "https://tendriller.dev";
function req(path, init) {
  const url = path.startsWith("http") ? path : BASE + path;
  const { anonymous, ...rest } = init ?? {};
  const headers = new Headers(rest.headers);
  if (!anonymous && !headers.has("Cookie")) {
    for (const [k, v] of Object.entries(ownerHeaders(url))) if (!headers.has(k)) headers.set(k, v);
  }
  return exports.default.fetch(url, { ...rest, headers });
}
var ownerCookies = /* @__PURE__ */ new Map();
function randomTestIp() {
  const b = crypto.getRandomValues(new Uint8Array(3));
  return `198.${18 + (b[0] & 1)}.${b[1]}.${b[2]}`;
}
async function create(body = {}) {
  const { claim = true, listener = true, ...rest } = body;
  const email = typeof rest.owner === "string" ? rest.owner : `owner-${crypto.randomUUID()}@example.com`;
  const account = crypto.randomUUID();
  const db = env.ACCOUNTS;
  const now = Date.now();
  if (claim) await db.prepare("INSERT INTO accounts (id, created_at, email) VALUES (?, ?, ?)").bind(account, now, email).run();
  const res = await req("/api/tendrils", {
    method: "POST",
    headers: { "Content-Type": "application/json", "CF-Connecting-IP": randomTestIp() },
    body: JSON.stringify({ ...rest, owner: email })
  });
  if (res.status !== 201) throw new Error(`create failed: ${res.status} ${await res.text()}`);
  const h = await res.json();
  if (claim) ownerCookies.set(h.id, await signInAsOwner(h, account, email));
  if (listener) {
    const wake = await api(h, "PUT", "wake", { webhook: { url: "https://example.org/tendriller-test" } });
    if (!wake.ok) throw new Error(`wake setup failed: ${wake.status} ${await wake.text()}`);
  }
  return h;
}
async function signInAsOwner(h, account, email) {
  const db = env.ACCOUNTS;
  const now = Date.now();
  const raw = `test-${crypto.randomUUID()}`;
  await db.batch([
    db.prepare("INSERT INTO identities (provider, subject, account_id, login, email, created_at) VALUES ('google', ?, ?, ?, ?, ?)").bind(account, account, email.split("@")[0], email, now),
    db.prepare("INSERT INTO identity_emails (provider, subject, email) VALUES ('google', ?, ?)").bind(account, email),
    db.prepare("INSERT INTO sessions (hash, account_id, created_at, expires_at) VALUES (?, ?, ?, ?)").bind(await sha256Hex(raw), account, now, now + 864e5)
  ]);
  const key = new URL(h.page_url).pathname.split("/")[2];
  const redirect = await req(`/auth/page?tendril=${h.id}&key=${key}`, { headers: { Cookie: `__Host-tendriller=${raw}` }, redirect: "manual" });
  if (redirect.status !== 303) throw new Error(`owner sign-in failed: ${redirect.status} ${await redirect.text()}`);
  const session = await req(redirect.headers.get("Location"), { redirect: "manual" });
  const cookie = session.headers.get("Set-Cookie")?.split(";")[0];
  if (!cookie) throw new Error(`no page session cookie: ${session.status}`);
  return cookie;
}
function ownerHeaders(pageUrl) {
  const url = new URL(pageUrl);
  if (!url.hostname.endsWith(".tendriller.site")) return {};
  const cookie = ownerCookies.get(url.hostname.split(".")[0]);
  return cookie ? { Cookie: cookie, Origin: url.origin } : {};
}
async function api(h, method, path, body, headers = {}, token = h.token) {
  const init = { method, headers: { Authorization: `Bearer ${token}`, ...headers } };
  if (body !== void 0) {
    if (typeof body === "string" || body instanceof ArrayBuffer || body instanceof Uint8Array) init.body = body;
    else {
      init.body = JSON.stringify(body);
      init.headers["Content-Type"] = "application/json";
    }
  }
  return req(h.api + (path ? "/" + path : ""), init);
}
function stub(id) {
  return env.TENDRIL.get(env.TENDRIL.idFromName(id));
}
function inDO(id, fn) {
  return runInDurableObject(stub(id), (inst) => fn(inst));
}

// contract/discovery.mjs
var PEER_DIRECTORY_LIMITS = Object.freeze({
  peers: 64,
  peersPerPrincipal: 8,
  routes: 4,
  profiles: 8,
  defaultTtlMs: 12e4,
  minTtlMs: 3e4,
  maxTtlMs: 6e5,
  advertisementBytes: 16384
});

// contract/invitations.mjs
var PEER_INVITATION_PROTOCOL = "tendriller.invitations.v1";
var PEER_INVITATION_LIMITS = Object.freeze({
  listeners: 64,
  listenersPerPrincipal: 8,
  pending: 8,
  invitationsPerMinute: 32,
  messageBytes: 1024,
  openTimeoutMs: 15e3
});

// contract/peers.mjs
var PEER_RENDEZVOUS_PROTOCOL = "tendriller.rendezvous.v1";
var PEER_RENDEZVOUS_LIMITS = Object.freeze({
  descriptionBytes: 64 * 1024,
  messageBytes: 128 * 1024,
  sessions: 16,
  lifetimeMs: 6e4
});

// server/test/fixture-peer-socket.ts
var bytes = (value) => typeof value === "string" ? new TextEncoder().encode(value).byteLength : value.byteLength;
function testPeerSocket(upgrade, traffic, kind) {
  class Socket extends EventTarget {
    readyState = 0;
    socket;
    constructor() {
      super();
      void this.open();
    }
    finish(code, reason) {
      if (this.readyState === 3) return;
      this.readyState = 3;
      this.dispatchEvent(Object.assign(new Event("close"), { code, reason }));
    }
    async open() {
      try {
        const response = await upgrade(), socket = response.webSocket;
        if (response.status !== 101 || !socket) throw new Error(`Rendezvous upgrade failed: ${response.status} ${await response.text()}`);
        if (this.readyState === 3) {
          socket.accept();
          socket.close(1e3, "Test client cancelled");
          return;
        }
        this.socket = socket;
        socket.addEventListener("message", (event) => {
          traffic[kind === "rendezvous" ? "rendezvousReceivedBytes" : "invitationReceivedBytes"] += bytes(event.data);
          this.dispatchEvent(new MessageEvent("message", { data: event.data }));
        });
        socket.addEventListener("close", (event) => this.finish(event.code, event.reason));
        socket.addEventListener("error", () => this.dispatchEvent(new Event("error")));
        this.readyState = 1;
        socket.accept();
        this.dispatchEvent(new Event("open"));
      } catch (error) {
        if (this.readyState === 3) return;
        this.dispatchEvent(Object.assign(new Event("error"), { error }));
        this.finish(1011, error instanceof Error ? error.message : "Rendezvous upgrade failed");
      }
    }
    send(data) {
      if (this.readyState !== 1 || !this.socket) throw new Error("Rendezvous socket is not open");
      this.socket.send(data);
      traffic[kind === "rendezvous" ? "rendezvousSentBytes" : "invitationSentBytes"] += bytes(data);
    }
    close(code = 1e3, reason = "Test client closed") {
      if (this.readyState >= 2) return;
      if (!this.socket) {
        this.finish(code, reason);
        return;
      }
      this.readyState = 2;
      this.socket.close(code, reason);
    }
  }
  return new Socket();
}

// server/test/public-fixture.ts
async function initializeTestService(migrations) {
  await applyD1Migrations(env2.ACCOUNTS, migrations);
  await env2.ACCOUNTS.prepare("UPDATE service_state SET mode='open' WHERE id=1").run();
}
async function createTestPage(options = {}) {
  const { lifetime, ...selection } = options;
  const handle = await create({ mode: "dashboard", listener: false, ...selection });
  if (lifetime === "resident") {
    const response = await api(handle, "PATCH", "", { lifetime });
    if (!response.ok) throw new Error(`Resident test page setup failed: ${response.status} ${await response.text()}`);
  }
  const traffic = {
    httpRequests: 0,
    requestBodyBytes: 0,
    rendezvousUpgrades: 0,
    rendezvousSentBytes: 0,
    rendezvousReceivedBytes: 0,
    invitationUpgrades: 0,
    invitationSentBytes: 0,
    invitationReceivedBytes: 0
  };
  const request = (url, init) => {
    traffic.httpRequests++;
    if (init.body !== void 0 && init.body !== null) {
      if (typeof init.body === "string") traffic.requestBodyBytes += new TextEncoder().encode(init.body).byteLength;
      else if (init.body instanceof ArrayBuffer || ArrayBuffer.isView(init.body)) traffic.requestBodyBytes += init.body.byteLength;
      else throw new TypeError("The public test fixture accepts JSON, text or binary request bodies");
    }
    if (new Headers(init.headers).get("Upgrade")?.toLowerCase() === "websocket")
      traffic[new URL(url).pathname.endsWith("/peers/invitations") ? "invitationUpgrades" : "rendezvousUpgrades"]++;
    return req(url, init);
  };
  const pageApi = (url, headers) => (method, path, body) => request(
    `${url}_tendril/${path}`,
    {
      method,
      headers: { ...headers, ...body === void 0 ? {} : { "Content-Type": "application/json" } },
      ...body === void 0 ? {} : { body: JSON.stringify(body) }
    }
  );
  const workflow = (url, headers) => (module, operation, data = {}, guards = {}, cid = crypto.randomUUID()) => request(
    `${url}workflows/${encodeURIComponent(module)}/${encodeURIComponent(operation)}`,
    {
      method: "POST",
      headers: { ...headers, "Content-Type": "application/json" },
      body: JSON.stringify({ cid, expected_generations: guards, data })
    }
  );
  const owner = workflow(handle.page_url + "_tendril/", ownerHeaders(handle.page_url));
  const agentApi = (method, path, body) => {
    const raw = typeof body === "string" || body instanceof ArrayBuffer || body instanceof Uint8Array;
    return request(`${handle.api}${path ? "/" + path : ""}`, {
      method,
      headers: { Authorization: `Bearer ${handle.token}`, ...body === void 0 || raw ? {} : { "Content-Type": "application/json" } },
      ...body === void 0 ? {} : { body: raw ? body : JSON.stringify(body) }
    });
  };
  const agent = (module, operation, data = {}, guards = {}, cid = crypto.randomUUID()) => agentApi("POST", `workflows/${encodeURIComponent(module)}/${encodeURIComponent(operation)}`, { cid, expected_generations: guards, data });
  const rendezvous = (base, headers) => (channel, peerId) => testPeerSocket(() => request(
    `${base}peers/rendezvous?${new URLSearchParams({ channel, peerId })}`,
    { headers: { ...headers, Upgrade: "websocket", "Sec-WebSocket-Protocol": PEER_RENDEZVOUS_PROTOCOL } }
  ), traffic, "rendezvous");
  const invitations = (base, headers) => (peerId) => testPeerSocket(() => request(
    `${base}peers/invitations?${new URLSearchParams({ peerId })}`,
    { headers: { ...headers, Upgrade: "websocket", "Sec-WebSocket-Protocol": PEER_INVITATION_PROTOCOL } }
  ), traffic, "invitation");
  return {
    owner,
    agent,
    /** Exact observed requests/frame bytes, excluding synthetic identity/page setup. */
    get hostTraffic() {
      return Object.freeze({ ...traffic });
    },
    rendezvousSocket: rendezvous(handle.api + "/", { Authorization: `Bearer ${handle.token}` }),
    ownerRendezvousSocket: rendezvous(handle.page_url + "_tendril/", ownerHeaders(handle.page_url)),
    invitationSocket: invitations(handle.api + "/", { Authorization: `Bearer ${handle.token}` }),
    ownerInvitationSocket: invitations(handle.page_url + "_tendril/", ownerHeaders(handle.page_url)),
    ownerApi: pageApi(handle.page_url, ownerHeaders(handle.page_url)),
    api: agentApi,
    async participant() {
      const account = crypto.randomUUID(), secret = crypto.randomUUID();
      await env2.ACCOUNTS.prepare("INSERT INTO accounts(id,created_at,email) VALUES(?,?,?)").bind(account, Date.now(), `${account}@example.test`).run();
      const link = await inDO(handle.id, async (t) => {
        const invitation = await t.createLink("guest", "test participant", null);
        t.db.run("INSERT INTO guest_accounts(account_id,link_id,approved,created_at) VALUES(?,?,1,?)", account, invitation.id, t.now());
        t.db.run("INSERT INTO page_sessions(hash,account_id,role,expires_at) VALUES(?,?,?,?)", await sha256Hex(secret), account, "guest", t.now() + 864e5);
        return t.renderLink(invitation);
      });
      const headers = { Cookie: `__Host-tendril=${secret}`, Origin: new URL(link.url).origin };
      return {
        account,
        call: workflow(link.url + "_tendril/", headers),
        api: pageApi(link.url, headers),
        rendezvousSocket: rendezvous(link.url + "_tendril/", headers),
        invitationSocket: invitations(link.url + "_tendril/", headers)
      };
    },
    async display() {
      const link = await inDO(handle.id, async (t) => t.renderLink(await t.createLink("display", "test display", null)));
      return workflow(link.url + "_tendril/", { Cookie: "", Origin: new URL(link.url).origin });
    },
    async advance(milliseconds) {
      if (!Number.isFinite(milliseconds) || milliseconds < 0) throw new TypeError("Advance by a finite nonnegative duration");
      await inDO(handle.id, (t) => {
        t.skew += milliseconds;
      });
    },
    async restart() {
      let requested = false;
      try {
        await inDO(handle.id, (t) => {
          requested = true;
          t.ctx.abort("Public test fixture restart");
        });
      } catch (error) {
        if (!requested) throw error;
      }
    }
  };
}
export {
  createTestPage,
  initializeTestService
};
